package com.calculator.lesson00.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText firstNumber = (EditText) findViewById(R.id.sumFirst);
        final EditText secondNumber = (EditText) findViewById(R.id.sumSecond);
        final TextView result = (TextView) findViewById(R.id.resultText);

        Button evaluate = (Button) findViewById(R.id.computeSum);
        evaluate.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {


                try {

                    int add1 = Integer.parseInt(firstNumber.getText().toString());
                    int add2 = Integer.parseInt(secondNumber.getText().toString());

                    int evaluationresult = add1 + add2;

                    result.setText(evaluationresult + "");


                } catch (NumberFormatException nfe) {
                    Toast.makeText(getApplicationContext(), R.string.toastExceptionMessage, Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
