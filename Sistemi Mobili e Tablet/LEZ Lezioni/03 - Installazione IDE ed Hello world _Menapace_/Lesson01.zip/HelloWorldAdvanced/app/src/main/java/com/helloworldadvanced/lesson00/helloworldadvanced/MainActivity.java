package com.helloworldadvanced.lesson00.helloworldadvanced;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Prepare the hello label to be printed.
        TextView inputText = (TextView) findViewById(R.id.insertTextLabel);
        inputText.setText(R.string.inputText);

        ImageView insert = (ImageView) findViewById(R.id.addText);
        insert.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg) {

                EditText textField = (EditText) findViewById(R.id.inputText);

                String input = textField.getText().toString();

                if (input.length() > 0) {
                    TextView welcomeLabel = (TextView) findViewById(R.id.printedLabel);

                    //Prepare the text to be printed
                    StringBuilder sb = new StringBuilder();
                    sb.append(welcomeLabel.getText());
                    sb.append("\n");
                    sb.append(input);

                    //Insert the text into the TextView
                    welcomeLabel.setText(sb.toString());

                    //Clear the EditText
                    textField.setText("");
                }
            }
        });
    }
}
