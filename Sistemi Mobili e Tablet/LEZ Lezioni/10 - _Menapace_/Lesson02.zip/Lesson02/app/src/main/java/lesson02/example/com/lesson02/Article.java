package lesson02.example.com.lesson02;

import android.graphics.Bitmap;

public class Article {

    private String articleName;
    private Bitmap articleImage;

    public String getArticleName() {
        return articleName;
    }

    public void setArticleName(String articleName) {
        this.articleName = articleName;
    }

    public Bitmap getImage() {
        return articleImage;
    }

    public void setImage(Bitmap image) {
        this.articleImage = image;
    }
}