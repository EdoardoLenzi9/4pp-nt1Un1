package lesson02.example.com.lesson02;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

/**
 * Created by Carlo on 20/02/2016.
 */
public class SillyAdapter extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        String[] arrayOfResources = { "Article1", "Article2", "Article3" };
        setListAdapter(new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1, arrayOfResources));

    }
}