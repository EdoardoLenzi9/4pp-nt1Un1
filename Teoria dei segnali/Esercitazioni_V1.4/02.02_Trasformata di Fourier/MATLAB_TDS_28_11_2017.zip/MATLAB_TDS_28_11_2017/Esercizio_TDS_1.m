%vettore delle frequenze (asse x)
f=-500e3:1e3:500e3;

%parametri numerici (dati dall'esercizio)
V0=1.25;
gamma=25e4;
T=1e-5;
teta=5e-6;

%calcolo e grafico spettro in ampiezza
ampl_spectr=(V0/T)*(1./sqrt(((gamma^2-(2*pi*f).^2)).^2+(4*pi*f*gamma).^2));
plot(f./1e3,ampl_spectr); %scala frequenziale usata: KHz

%apre una nuova figura
figure

%calcolo e grafico spettro in fase
phase_spectr=atan(-(4*pi*f*gamma)./(gamma^2-(2*pi*f).^2))-2*pi*f*teta;
plot(f./1e3,phase_spectr); %scala frequenziale usata: KHz