%vettore delle frequenze (asse x)
f=-6e5:1e2:6e5;

%Parametri numerici
A=1;
T=1e-4;
tau=1e-5;

%calcolo e disegno spettro in ampiezza
ampl_spectr=A*tau*((sinc(0.5.*f.*tau)).^2).*(abs(sin(2*pi.*f.*T)));
plot(f./1e3,ampl_spectr);